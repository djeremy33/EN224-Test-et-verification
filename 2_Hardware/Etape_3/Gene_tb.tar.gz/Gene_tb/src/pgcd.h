#ifndef __PGCD__
#define __PGCD__

int PGCD(int A, int B);

int PGCD_euclide(int A, int B);

int myRand();

#endif //_pgcd.h_